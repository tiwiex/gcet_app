import frappe
from frappe.utils import getdate, flt
from erpnext.accounts.utils import get_fiscal_year_data

def execute(filters=None):
    columns = get_columns(filters)
    data = get_data(filters, columns)
    return columns, data

def get_columns(filters):
    columns = [{
        "label": "Account",
        "fieldname": "account",
        "fieldtype": "Link",
        "options": "Account",
        "width": 200
    }]
    for label, _, _ in get_period_date_ranges(filters):
        columns.append({"label": f"{label} (₦)", "fieldtype": "Currency", "fieldname": f"{label}_ngn", "width": 120})
        columns.append({"label": f"{label} ($)", "fieldtype": "Float", "fieldname": f"{label}_usd", "width": 120})
    return columns

def get_data(filters, columns):
    accounts = frappe.get_all("Account", filters={
        "company": filters.company,
        "report_type": "Balance Sheet"
    }, fields=["name"])
    data = []
    for acc in accounts:
        row = {"account": acc.name}
        for label, start, end in get_period_date_ranges(filters):
            result = frappe.db.sql("""
                SELECT SUM(debit - credit) FROM `tabGL Entry`
                WHERE account = %s AND posting_date BETWEEN %s AND %s AND docstatus = 1 AND company = %s
            """, (acc.name, start, end, filters.company))
            ngn_val = flt(result[0][0]) if result and result[0][0] else 0
            row[f"{label}_ngn"] = ngn_val
            row[f"{label}_usd"] = ngn_val / flt(filters.usd_rate or 1000)
        data.append(row)
    return data

def get_period_date_ranges(filters):
    from dateutil.relativedelta import relativedelta
    import calendar
    fy_data = frappe.get_doc("Fiscal Year", filters.fiscal_year)
    start_date = getdate(fy_data.year_start_date)
    end_date = getdate(fy_data.year_end_date)
    periodicity = filters.periodicity or "Monthly"

    current = start_date
    periods = []

    while current <= end_date:
        if periodicity == "Monthly":
            label = current.strftime("%b %Y")
            period_end = current.replace(day=calendar.monthrange(current.year, current.month)[1])
        elif periodicity == "Quarterly":
            quarter = (current.month - 1) // 3 + 1
            label = f"Q{quarter} {current.year}"
            period_end = current + relativedelta(months=3, days=-1)
        else:
            label = str(current.year)
            period_end = current.replace(month=12, day=31)
        periods.append((label, current, min(period_end, end_date)))
        current = period_end + relativedelta(days=1)
    return periods