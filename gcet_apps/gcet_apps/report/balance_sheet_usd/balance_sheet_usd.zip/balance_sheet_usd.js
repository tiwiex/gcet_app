frappe.query_reports["Balance Sheet USD"] = {
    onload: function(report) {
        // Optional JS customization
    }
};